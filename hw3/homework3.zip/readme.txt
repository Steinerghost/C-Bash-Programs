By: Casey Ford
Compile by using the following line:

	gcc -o smallsh smallsh.c
